let get2Button = document.querySelector('.but');

if (get2Button) {
    get2Button.addEventListener('click', function () {
        let input = document.querySelector('.email');
        let emailSpan = document.querySelector('.email-span');

        function isValidEmail(value) {
            // Check if the email ends with "@gmail.com"
            return value.trim().toLowerCase().endsWith("@gmail.com");
        }

        if (!input.value.trim()) {
            emailSpan.innerText = '⛒ Please enter a valid email address or phone number.';
            input.classList.add('placeholder-hovered', 'place');
        } else if (!isValidEmail(input.value)) {
            emailSpan.innerText = '⛒ Invalid email format. Email must end with @gmail.com';
            input.classList.add('placeholder-hovered', 'place');
        } else {
            emailSpan.innerText = '';
            input.classList.remove('place', 'placeholder-hovered');
        }

        let input1 = document.querySelector('.pass');
        let passSpan = document.querySelector('.pass-span');

        if (!input1.value.trim()) {
            passSpan.innerText = '⛒ Your password must contain 4 between for and 50 characters.';
            input1.classList.add('placeholder-hovered', 'place', 'saad');
        } else {
            passSpan.innerText = '';
            input1.classList.remove('place', 'placeholder-hovered', 'saad');
        }
    });

    let handleLogoClick = () => {
        window.location.href = '../index.html';
    }

    let logo = document.querySelector('.logo');

    if (logo) {
        logo.addEventListener("click", handleLogoClick);
    }
}