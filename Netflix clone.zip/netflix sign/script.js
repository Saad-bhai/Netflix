document.addEventListener('DOMContentLoaded', function() {
    let myInput = document.getElementById('myInput');

    myInput.addEventListener('blur', function() {
        myInput.style.borderColor = 'red';
    });

    myInput.addEventListener('focus', function() {
        myInput.style.borderColor = ''; // Resetting border color on focus
    });
});