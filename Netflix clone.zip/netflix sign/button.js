 let urlParams = new URLSearchParams(window.location.search);
 let enteredText = urlParams.get('text');

  document.querySelector('.name').innerText = enteredText;
  
  
    function showPasswordRequired() {
      document.querySelector('.pass').innerText = 'Password is required.';
      
    }

      let handleLogoClick0 = () => {
        window.location.href = 'sign.html';
    }

    let sign = document.querySelector('.sign');

    if (sign) {
        sign.addEventListener("click", handleLogoClick0);
    }

    let handleLogoClick = () => {
        window.location.href = '../index.html';
    }

    let logo = document.querySelector('.logo');

    if (logo) {
        logo.addEventListener("click", handleLogoClick);
    }