document.addEventListener('DOMContentLoaded', () => {

    let get2Button = document.querySelector('.get2');
    let inputField = document.querySelector('.input1');
    let placeholderStyle;

    function setValidStyles() {
        inputField.style.borderColor = 'rgba(93, 221, 125, 1)';
        inputField.classList.add('inputa');
    }

    function setInvalidStyles() {
        inputField.style.borderColor = 'red';
        inputField.classList.remove('inputa');
    }

    function isValidEmail(value) {
        return value.trim().toLowerCase().endsWith("@gmail.com");
    }

    get2Button.addEventListener('click', function () {
        let trimmedValue = inputField.value.trim().toLowerCase();

        if (trimmedValue !== "" && isValidEmail(trimmedValue)) {
            setValidStyles();
            var enteredText = inputField.value;
            get2Button.style.background="rgba(167, 21, 21, 1)";
              setTimeout(() => {
                     window.location.href = "netflix sign/button.html?text=" + encodeURIComponent(enteredText)
               }, 6000);
        ;
            
        } else {
           inputField.style.borderColor="dimgray";

            // If the placeholder is empty, focus on the input field and select its text
            if (!inputField.value) {
                inputField.focus();
                inputField.select();
            }
        }
    });

    inputField.addEventListener('input', function () {
        let trimmedValue = inputField.value.trim().toLowerCase();

        if (trimmedValue === "") {
            inputField.style.borderColor = '';
        } else if (isValidEmail(trimmedValue)) {
            setValidStyles();
        } else {
            inputField.style.borderColor = "dimgray";
            inputField.classList.remove('inputa');
        }
    });

    // Apply stored placeholder style
    if (placeholderStyle) {
        inputField.setAttribute('style', (inputField.getAttribute('style') || '') + placeholderStyle);
    }

    // Save the placeholder style when leaving the page
    window.addEventListener('beforeunload', () => {
        localStorage.setItem('placeholderStyle', ';' + window.getComputedStyle(inputField, '::placeholder').cssText);
    });
});
let signin = document.querySelector(".sign");

let handlesign = () => {
  window.location.href="netflix sign/sign.html";
  signin.style.background="rgba(167, 21, 21, 1)";
}
signin.addEventListener('click',handlesign);

document.addEventListener('DOMContentLoaded', () => {

    let proField = document.querySelector('.pro');
    let getButton = document.querySelector('.get1');
    let placeholderStyle;
    
    function setValidStyles() {
        proField.style.borderColor = 'rgba(93, 221, 125, 1)';
        proField.classList.add('inputa');
    }

    function setInvalidStyles() {
        proField.style.borderColor = 'red';
        proField.classList.remove('inputa');
    }

    function isValidEmail(value) {
        return value.trim().toLowerCase().endsWith("@gmail.com");
    }

    getButton.addEventListener('click', function () {
        let trimmedValue = proField.value.trim().toLowerCase();

        if (trimmedValue !== "" && isValidEmail(trimmedValue)) {
            setValidStyles();
            var enteredText = proField.value;
            window.location.href = "netflix sign/button.html?text=" + encodeURIComponent(enteredText);
        } else {
           proField.style.borderColor="dimgray";

            // If the placeholder is empty, focus on the input field and select its text
            if (!proField.value) {
                proField.focus();
                proField.select();
            }
        }
    });

    proField.addEventListener('input', function () {
        let trimmedValue = proField.value.trim().toLowerCase();

        if (trimmedValue === "") {
            proField.style.borderColor = '';
        } else if (isValidEmail(trimmedValue)) {
            setValidStyles();
        } else {
            proField.style.borderColor = "dimgray";
            proField.classList.remove('inputa');
        }
    });

    // Apply stored placeholder style
    if (placeholderStyle) {
        proField.setAttribute('style', (proField.getAttribute('style') || '') + placeholderStyle);
    }

    // Save the placeholder style when leaving the page
    window.addEventListener('beforeunload', () => {
       localStorage.setItem('placeholderStyle', window.getComputedStyle(proField, '::placeholder').cssText);
    });
})